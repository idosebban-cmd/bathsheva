# Request for quotation: Faro table lamp (battery pack, control board and LEDs)

| From | [COMPANY NAME] |
|---|---|
| Contact | [CONTACT NAME, ROLE] |
| Email | [EMAIL] |
| Phone | [PHONE] |
| Address | [COMPANY ADDRESS] |
| Quote deadline | [QUOTE DEADLINE] |
| Reference | FARO-RFQ, CAD v1, 2026-10-07 |

Faro table lamp · CAD version v1 · units: millimetres

> **Values marked UNVERIFIED are our working assumptions: confirm them or propose better. Items marked COMPLIANCE or SAFETY must be backed by certificates and test reports for the exact part.**

## 1. Product

A cordless decorative table lamp in spun aluminium and brass, 300 mm tall: a frosted glass lantern at the top and five glowing windows in the tower. The metalwork is quoted separately; this RFQ covers the battery pack, the control board and the two LED light sources.

## 2. Quantities and samples

- Please quote each of these order quantities: 300, 500, 2,000 sets (one set = one battery pack, one control board, one lantern LED module, one tower light). Tell us your MOQ.
- Samples: please quote 5 sample sets and the lead time.
- Our likely first order is 300 to 500 sets, depending on pre-orders. Please quote all three tiers.

## 3. Battery pack: pre-certified 2 x 18650

- Two branded 18650 Li-ion cells, about 3,350 mAh class (name the cell brand and model).
- Configuration: 1S2P (3.6 V nominal), so USB-C charging stays simple. If you strongly prefer 2S (7.2 V), quote it as an alternative with your reasons.
- Protection circuit in the pack: over-charge, over-discharge, over-current and short circuit, plus an NTC thermistor so charging stops outside a safe temperature range.
- Pass-through charging: the lamp must work normally while it charges from USB-C. Charging with the lamp on must not cycle or over-stress the cells. Tell us whether the power path is on the pack or on the control board.
- Size: it must fit within 70 × 38 × 19.5 mm lying flat (cells side by side), with leads.
- Leads and a polarised connector to the control board (for example JST PH 2.0), about 80 mm long (UNVERIFIED). The end user must be able to replace the pack with ordinary tools.
- COMPLIANCE: the pack must be pre-certified. Send the UN38.3 test summary and the IEC 62133-2 test report for this exact pack (cells, configuration and protection board), plus the safety data sheet. Pack labelling must follow UK requirements (crossed-out wheelie bin, capacity in mAh/Wh); if CE for the EU follows, EU Batteries Regulation 2023/1542 labelling too.

## 4. Control board

- USB-C receptacle (5 V input; no USB PD needed; CC resistors so C-to-C cables work). It mounts on the board at the rear of the base, receptacle centre 11 mm above the base underside. Board envelope about 40 × 25 mm (UNVERIFIED; tell us your size).
- Li-ion charger for the pack with the NTC input, and the pass-through power path (section 3).
- Two constant-current LED channels: lantern about 1.5 W and tower light about 0.8 W (UNVERIFIED). Match the voltage and current to the LEDs you quote.
- Dimming from a slim rotary potentiometer with switch (9 mm class, D-shaft, M7 bushing), mounted in the tower. Switch off at the end of travel. Both channels dim together, with the tower at a fixed share of the lantern set at the factory. Smooth dimming down to 5% or lower, with no visible flicker (PWM at 3 kHz or more, or analogue dimming: IEEE 1789 low-risk).
- Please quote the potentiometer and its harness too.
- Low battery: the lantern blinks twice, then the lamp dims and switches off before the cells are deeply discharged. Standby current 50 µA or less (UNVERIFIED).
- A small charging indicator LED next to the USB-C port. No other indicator on the lamp.
- Wiring harness: about 250 mm from the base to the lantern LED through the tower, plus leads to the tower light and the potentiometer, with connectors.
- COMPLIANCE: please quote USB-C charging and the board tested and documented for UKCA marking (UK launch): EMC (BS EN IEC 55015 and BS EN 61547), safety (BS EN IEC 62368-1 or BS EN 60598-1 as applicable) and RoHS. CE for the EU may follow: tell us what it would add. Send the test reports; we will check them with an accredited test lab.

## 5. LEDs

- Lantern LED module: a round aluminium-core board Ø38 mm on a heat spreader. Emitter area Ø20 mm or less, total height 5 mm or less, 2700 K, CRI 90 or more (R9 above 50 preferred), about 1.5 W. It lights a frosted glass lantern from below; the board rests on a ledge.
- Tower light: 4 warm-white LED filament strips, 2700 K, about 0.8 W in total, about 73 mm of light along a Ø10 mm aluminium spine. The tube behind the windows is 83 mm long. Please quote with and without the spine.
- Colour consistency: 3-step MacAdam binning. Please send datasheets, and LM-80 reports if you have them.
- COMPLIANCE: light sources must meet the UK ecodesign and energy labelling rules for light sources (the GB versions of EU 2019/2020 and 2019/2015) where they apply; please confirm.

## 6. Runtime

Target: at least 8 h at full brightness with both lights on. Our estimate is 8.0 h from 24.1 Wh and 2.3 W (UNVERIFIED). Please give your own runtime and charge time for what you quote.

## 7. Alternatives to quote

- Option B (mains, no battery): a certified external 12 V adapter (UK plug; EU plug may follow), a low-voltage cable and an internal DC-DC constant-current driver for both channels, with the same dimming.
- Capacitive touch dimming on the brass finial instead of the knob.

## 8. Price breakdown requested

| Item | Qty | Unit price | Tooling / NRE (one-off) | Certification (one-off) | MOQ | Lead time |
|---|---|---|---|---|---|---|
| Battery pack | 300 |  |  |  |  |  |
| Battery pack | 500 |  |  |  |  |  |
| Battery pack | 2,000 |  |  |  |  |  |
| Control board + potentiometer + harness | 300 |  |  |  |  |  |
| Control board + potentiometer + harness | 500 |  |  |  |  |  |
| Control board + potentiometer + harness | 2,000 |  |  |  |  |  |
| Lantern LED module | 300 |  |  |  |  |  |
| Lantern LED module | 500 |  |  |  |  |  |
| Lantern LED module | 2,000 |  |  |  |  |  |
| Tower light | 300 |  |  |  |  |  |
| Tower light | 500 |  |  |  |  |  |
| Tower light | 2,000 |  |  |  |  |  |

## 9. Commercial terms

- Please quote both: FOB (port of loading); and DDP to our UK address: [DELIVERY ADDRESS, to be filled in].
- Currency: GBP or USD. State which, and keep it the same across the quote.
- Prices valid for at least 90 days; state payment terms and any tooling deposit.

## 10. Questions for the supplier

- Datasheets for the cells, the protection board, the charger and driver ICs, and the LEDs.
- Certificates and test reports: what exists already and what needs testing, with cost and time.
- Shipping: how you ship the pack (UN3480 alone, or UN3481 packed with equipment) and any surcharge.
- Warranty, country of origin, and the shelf life and storage charge level of the packs.
- Suggested changes that would cut cost or risk.

## 11. Space available (from our CAD)

| Item | Space |
|---|---|
| Battery bay in the base | 70 × 38 × 19.5 mm, lying flat; inside height of the base 23.5 mm |
| Control board | about 40 × 25 mm at the base rear; USB-C centre 11 mm above the underside |
| Lantern LED board | Ø38 mm, rests on the gallery ledge (Ø34 mm bore); it lifts out through a Ø46 mm opening |
| Tower light | Ø10 mm spine, 178 mm long; Ø57 mm clear inside the diffuser tube |
| Potentiometer | Ø12 × 9 mm body behind the tower wall, M7 bushing |

## 12. Battery compliance (for your information)

- COMPLIANCE: Li-ion cells must have a protection circuit (over-charge, over-discharge, over-current and short circuit) with thermal protection for charging.
- COMPLIANCE: UN38.3 test summary needed for the cells and pack before shipping (air and sea transport rules for lithium batteries). Baseline: a pre-certified pack whose supplier provides the UN38.3 summary; check it covers the exact pack (cells, configuration, protection board) and is current. A custom pack needs its own testing (scenario c).
- COMPLIANCE: IEC 62133-2 certification for the cells and pack (expected for UK sale, and for the EU if CE follows): supplied with the pre-certified pack; a custom pack needs its own report.
- COMPLIANCE: EU Batteries Regulation (EU) 2023/1542 (applies if EU sale follows the UK launch): from 18 Feb 2027 portable batteries in appliances must be readily removable and replaceable by the end user with commonly available tools; plus labelling (CE, separate collection symbol, capacity) and producer registration. The screwed bottom plate (M2.5, standard hex key) is designed for this.
- COMPLIANCE: UK: Waste Batteries and Accumulators Regulations 2009 (producer registration and take-back; UK rules are being revised). Verify with a compliance consultant.
- COMPLIANCE: USB-C charging: confirm charging safety and EMC with the control-board supplier (e.g. IEC 62368-1 / EN 55015 as applicable).
