Faro table lamp: request for quotation pack (2026-10-06, CAD v1)

mechanical/   for metalwork, glass and finishing suppliers:
              rfq.pdf (and rfq.md), drawings/ (PDF + SVG per part), step/ (STEP per part + assembly), bom.csv
electronics/  for battery and electronics suppliers:
              rfq_electronics.pdf (and .md): pre-certified 2 x 18650 pack, control board with dimming, LEDs

Quantities to quote: 300, 500, 2,000 units.
Units: millimetres. Values marked UNVERIFIED are working assumptions; SAFETY and COMPLIANCE items need certificates.
