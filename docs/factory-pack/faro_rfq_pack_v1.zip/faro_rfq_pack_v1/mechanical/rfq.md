# Request for quotation: Faro table lamp (metalwork, glass and finishing)

Bathsheva London · 2026-10-06 · CAD version v1 · units: millimetres

> **Values marked UNVERIFIED are design placeholders or unverified data. Items marked SAFETY or COMPLIANCE must be verified with a qualified engineer or accredited test lab before production.**

## 1. Product summary

A premium decorative cordless table lamp in the form of a lighthouse: black base with a brass nameplate, cream tower with a red lower section and five glowing windows spiralling up it, brass gallery and railing, frosted lantern and a red twist-lock cap with a brass finial. Rechargeable over USB-C. Second product of Bathsheva London, after the Atelier speaker.

- Overall height 300 mm (plus a 1.9 mm felt pad), base Ø113 mm, tower Ø92→65 mm, lantern Ø55 mm. Form and proportions follow our approved prototype.
- Base: spun aluminium shell, gloss black, with a laser-cut steel weight plate round the battery; aluminium bottom plate on four M2.5 screws so the user can replace the battery; felt pad on magnets.
- Cream band: turned aluminium ring; the base screws into it (three M3) and the tower is bonded on its spigot.
- Tower: spun aluminium cone, two-tone lacquer (red lower section, masked line), 5 arched windows laser-cut after spinning, an opal borosilicate diffuser tube (window zone only) and a tower light behind them.
- Gallery and railing: spun brass shell with a soldered turned locating ring; photo-etched brass railing rolled into a ring (please also quote soldered brass wire and lost-wax casting).
- Lantern: frosted borosilicate tube inside a brass frame (rings turned from tube, soldered mullions); the red spun cap twist-locks onto the frame with a turned brass bayonet spigot (four lugs, 20° turn) and a brass ball finial.
- Construction: bonded and screwed, no central rod; no visible fixings.
- Cordless: 2 x 18650 Li-ion pack, USB-C charging, rotary dimmer with a solid brass knob on the tower. The electronics are quoted separately by electronics suppliers (section 6).
- Target total lamp mass 1.2 kg (estimate from CAD 1.20 kg; UNVERIFIED).

Where production departs from the 3D-printed prototype:

| Feature | Prototype | Production (please confirm or propose better) |
|---|---|---|
| Shell walls | Printed, 2.5 mm tower wall; solid printed cap and base | Spun aluminium base, tower and cap with a real wall (default 1.5 mm, typical spinning 1.0–2.0 mm) |
| Red lower tower | Separate printed red band glued under the tower | One spun cone lacquered in two colours with a masked line; removes a joint |
| Window diffusers | Five frosted resin inserts, numbered, glued behind the windows | One opal borosilicate tube inside the tower behind all five windows (glass, no plastic on view); no numbering needed. It covers only the window zone (5 mm past the lowest and highest window) and stands on a spider on the tower-light spine, so it is about half the full tower height |
| Window glow | Fairy lights coiled in the tower | Tower light: LED filament strips on a central spine inside the diffuser tube (bought-in) |
| Windows | Printed openings | Laser-cut after spinning (5-axis laser or fixture); adds a process and a fixture |
| Railing | Printed 1.6 mm round posts and rails | Photo-etched brass strip (0.6 mm) rolled into a ring and soldered; flat posts read the same at arm's length. Alternatives: soldered brass wire, or lost-wax cast |
| Gallery | Printed solid ring | Spun brass shell, 1.0 mm (flat top that is also the LED ledge, outer skirt, open underneath) with a turned brass locating ring soldered under it; same look from above and the side, far less brass than a solid turned ring |
| Lantern frame | One printed frame with the bayonet lip | Brass bottom ring and top band turned from tube (bayonet slots and lip machined) with brass mullion bars soldered or brazed between them |
| Small turned parts | Printed | Cream band, cap spigot, finial and knob turned from near-net stock (tube, ring blanks or close-fitting bar) rather than solid bar, to cut material and cycle time |
| Lantern glass | Printed/frosted 1.2 mm ring | Frosted (acid-etched) borosilicate tube, 2.0 mm wall (1.2 mm is thinner than stock tube) |
| Cap twist-lock | Lugs printed on a spigot under the cap | Lugs can't be spun: a turned brass spigot ring with the 4 lugs, bonded inside the spun cap |
| Cap collar | Printed red collar on the dome | Spun into the cap as a small neck (verify with the spinner); fallback: separate turned aluminium collar lacquered red |
| Nameplate | 1.2 mm plate in a 0.6 mm recess, raised lettering | 0.8 mm etched brass plate bonded on the surface (a recess can't be spun); lettering etched |
| Base fixing | Glued plate, coins for weight | Laser-cut steel weight plate screwed up into the cream band; aluminium bottom plate on 4 M2.5 screws into standoffs so the battery is user-replaceable; felt on a steel disc held by magnets |
| Battery bay | Sized for the bare cells (65 × 37 × 19 mm) | Sized for a pre-certified 2 x 18650 pack with its protection board and wrap: 70 × 38 × 19.5 mm; weight plate cut-out enlarged to match |
| Construction | Stacked and glued | No central rod: band screwed to the base through the weight plate, tower and gallery bonded on turned spigots, cap twist-locks onto the lantern |

## 2. Design constraint: visible metal must be solid metal

> **Every visible or touchable part must be solid metal (or glass for the lantern). No plastic, metallised plastic or metal-effect paint on plastic, at any volume. Brass details are solid brass or real plating on the metal part; no brass-look coatings. Hidden functional parts (gaskets, grommets, insulators, strain relief) may be plastic or rubber.**

## 3. Quantities

Please quote each of these order quantities: 300, 500, 2,000 lamps (one order of each size, not cumulative). Tell us your MOQ if it is above any of them.

## 4. Parts made to drawing

| Part no. | Part | Qty/lamp | Material | Process | Finish | Drawing / STEP | Notes |
|---|---|---|---|---|---|---|---|
| F-01 | Base | 1 | Aluminium 1050A (H14) | Metal spinning | Gloss black lacquer, clear-coated | F-01_base (.pdf/.svg), F-01_base.step | UNVERIFIED: wall thickness limits for metal spinning come from unverified rule data; SAFETY: tip-over stability to be tested on the finished lamp |
| F-02 | Bottom plate | 1 | Aluminium 5052, 2 mm | Laser cut, countersunk (made to drawing) | Black lacquer | F-02_bottom_plate (.pdf/.svg), F-02_bottom_plate.step |  |
| F-04 | Weight plate | 1 | Mild steel S275 (zinc plated) | Laser cut and zinc plated (made to drawing) | Zinc plated | F-04_weight_plate (.pdf/.svg), F-04_weight_plate.step | SAFETY: tip-over stability to be tested on the finished lamp |
| F-05 | Nameplate | 1 | Brass (CZ121 bar / CZ108 sheet) | Photo-etched brass sheet (formed after etching) | Tumble-polished, etched lettering filled black, clear lacquer | F-05_nameplate (.pdf/.svg), F-05_nameplate.step | UNVERIFIED: wall thickness limits for photo-etched brass sheet (formed after etching) come from unverified rule data |
| F-06 | Cream band | 1 | Aluminium 6061 (T6) | CNC turning from near-net stock (tube, ring blank or close-fitting bar) | Cream lacquer, clear-coated | F-06_cream_band (.pdf/.svg), F-06_cream_band.step | UNVERIFIED: wall thickness limits for cnc turning from near-net stock (tube, ring blank or close-fitting bar) come from unverified rule data |
| F-07 | Tower | 1 | Aluminium 1050A (H14) | Metal spinning | Two-tone lacquer (cream, red lower section, masked line), clear-coated | F-07_tower (.pdf/.svg), F-07_tower.step | UNVERIFIED: wall thickness limits for metal spinning come from unverified rule data; SAFETY: sharp edges must be removed |
| F-08 | Window diffuser | 1 | Borosilicate glass | Cut and finished glass tube | Opal (acid-etched) glass | F-08_window_diffuser (.pdf/.svg), F-08_window_diffuser.step | UNVERIFIED: wall thickness limits for cut and finished glass tube come from unverified rule data; SAFETY: glass breakage, edge finishing and retention to be verified |
| F-11 | Dimmer knob | 1 | Brass (CZ121 bar / CZ108 sheet) | CNC turning from near-net stock (tube, ring blank or close-fitting bar) | Tumble-polished, clear lacquer | F-11_dimmer_knob (.pdf/.svg), F-11_dimmer_knob.step | UNVERIFIED: wall thickness limits for cnc turning from near-net stock (tube, ring blank or close-fitting bar) come from unverified rule data |
| F-12 | Gallery | 1 | Brass (CZ121 bar / CZ108 sheet) | Metal spinning | Tumble-polished, clear lacquer | F-12_gallery (.pdf/.svg), F-12_gallery.step | UNVERIFIED: wall thickness limits for metal spinning come from unverified rule data |
| F-13 | Gallery railing | 1 | Brass (CZ121 bar / CZ108 sheet) | Photo-etched brass sheet (formed after etching) | Tumble-polished, clear lacquer | F-13_gallery_railing (.pdf/.svg), F-13_gallery_railing.step | UNVERIFIED: wall thickness limits for photo-etched brass sheet (formed after etching) come from unverified rule data |
| F-14 | Lantern frame | 1 | Brass (CZ121 bar / CZ108 sheet) | CNC turning from near-net stock (tube, ring blank or close-fitting bar) | Tumble-polished, clear lacquer | F-14_lantern_frame (.pdf/.svg), F-14_lantern_frame.step | UNVERIFIED: wall thickness limits for cnc turning from near-net stock (tube, ring blank or close-fitting bar) come from unverified rule data |
| F-15 | Lantern glass | 1 | Borosilicate glass | Cut and finished glass tube | Frosted (acid-etched inside) | F-15_lantern_glass (.pdf/.svg), F-15_lantern_glass.step | UNVERIFIED: wall thickness limits for cut and finished glass tube come from unverified rule data; SAFETY: glass breakage, edge finishing and retention to be verified |
| F-17 | Cap | 1 | Aluminium 1050A (H14) | Metal spinning | Red lacquer, clear-coated | F-17_cap (.pdf/.svg), F-17_cap.step | UNVERIFIED: wall thickness limits for metal spinning come from unverified rule data |
| F-18 | Cap bayonet spigot | 1 | Brass (CZ121 bar / CZ108 sheet) | CNC turning from near-net stock (tube, ring blank or close-fitting bar) | None (hidden when fitted) | F-18_cap_bayonet_spigot (.pdf/.svg), F-18_cap_bayonet_spigot.step | UNVERIFIED: wall thickness limits for cnc turning from near-net stock (tube, ring blank or close-fitting bar) come from unverified rule data |
| F-19 | Finial | 1 | Brass (CZ121 bar / CZ108 sheet) | CNC turning from near-net stock (tube, ring blank or close-fitting bar) | Tumble-polished, clear lacquer | F-19_finial (.pdf/.svg), F-19_finial.step | UNVERIFIED: wall thickness limits for cnc turning from near-net stock (tube, ring blank or close-fitting bar) come from unverified rule data |

Material and process are our current choice; please propose alternatives if they would be better or cheaper without breaking the design constraint.

## 5. Brass parts: please quote two ways

For each brass part, please quote (A) your preferred method and (B) the near-net basis below (turned from tube, ring blanks or close-fitting bar, or spun from a disc, rather than machined from solid bar). Tell us the blank or stock size you would buy for each.

| Part no. | Part | Finished size (mm) | Finished mass (g) | A: your preferred method | B: near-net basis |
|---|---|---|---|---|---|
| F-05 | Nameplate | 37.0 x 3.9 x 11.5 | 3 | Your choice (state it) | Photo-etched from 0.8 mm brass sheet, formed to the base radius (already near-net) |
| F-11 | Dimmer knob | 20.0 x 6.0 x 20.0 | 16 | Your choice (state it) | Turned from close-fitting brass bar (just over the knob diameter) |
| F-12 | Gallery | 90.0 x 90.0 x 13.7 | 121 | Your choice (state it) | Spun from a 1.0 mm CZ108 brass disc; locating ring turned from brass tube |
| F-13 | Gallery railing | 88.0 x 88.0 x 14.0 | 7 | Your choice (state it) | Photo-etched from 0.6 mm brass sheet, rolled and soldered (already near-net) |
| F-14 | Lantern frame | 55.0 x 55.0 x 41.3 | 34 | Your choice (state it) | Bottom ring and top band turned from brass tube; mullions from drawn brass flat |
| F-18 | Cap bayonet spigot | 67.6 x 67.6 x 7.3 | 37 | Your choice (state it) | Turned from brass tube close to the finished OD and bore |
| F-19 | Finial | 14.0 x 14.0 x 27.0 | 14 | Your choice (state it) | Turned from close-fitting brass bar (just over the ball diameter) |

## 6. Bought-in parts, hardware and operations

Operations to include in the price of the part they are done on:

- Laser-cut 5 arched windows in the spun tower (5-axis laser or fixture), deburr (on the tower)
- Masked two-tone lacquer: red lower section with a crisp, level line (on the tower)

Hardware and bought-in parts (quote them if you supply them, or tell us to supply them):

| Item | Component | Qty/lamp | Material | Notes |
|---|---|---|---|---|
| H1 | M3 x 25 socket screw, weight plate + base to band | 3 | Stainless steel (A2) | Heads in counterbores in the weight plate; length to suit the plate thickness. |
| H2 | M2.5 x 6 countersunk screw, hex socket | 4 | Stainless steel, black | Bottom plate to standoffs. |
| H3 | M2.5 hex standoff, aluminium | 4 | Aluminium | Length to suit the plate thickness. |
| H4 | N52 magnet 6 x 2 mm | 4 | NdFeB, nickel plated | Bonded into the bottom plate; hold the felt disc. |
| H5 | Silicone ring, diffuser | 2 | Silicone | Sized for the diffuser tube; section TBD. |
| — | Felt pad laminated to a 0.4 mm steel disc | 1 |  |  |
| — | Structural adhesive (tower, gallery, frame and spigot bonds), per lamp | 1 |  |  |

Electronics are sourced through a separate RFQ to electronics suppliers and are not part of this quote: Lantern LED; Tower light; Pre-certified Li-ion battery pack; Control board; USB-C charging cable; Slim rotary potentiometer with switch (9 mm class, D-shaft) and curved spacer washer. Their space is shown in the assembly STEP. If you can offer final assembly, please quote fitting them, wiring, the light-up / charge / dimming test and packing.

## 7. Price breakdown requested

For each part and each quantity, please break the unit price down as below so we can compare it line by line between suppliers. State the currency and the Incoterm. Brass parts: one row for method A and one for method B.

| Part no. | Method | Qty | Material (£) | Cycle time (min) | Process (£) | Finishing (£) | Setup per batch (£) | Tooling one-off (£) | Unit price (£) |
|---|---|---|---|---|---|---|---|---|---|
| F-01 | — | 300 |  |  |  |  |  |  |  |
| F-01 | — | 500 |  |  |  |  |  |  |  |
| F-01 | — | 2,000 |  |  |  |  |  |  |  |
| F-12 | A | 300 |  |  |  |  |  |  |  |
| F-12 | A | 500 |  |  |  |  |  |  |  |
| F-12 | A | 2,000 |  |  |  |  |  |  |  |
| F-12 | B | 300 |  |  |  |  |  |  |  |
| F-12 | B | 500 |  |  |  |  |  |  |  |
| F-12 | B | 2,000 |  |  |  |  |  |  |  |
| … |  |  |  |  |  |  |  |  |  |

(£) means the amount in your currency. Please also state: material grade and the blank / stock size you buy per part, the machine or process used, and who owns the tooling.

## 8. Questions for the supplier

- Minimum order quantity (MOQ) per part and for the assembled lamp.
- Tooling: what is needed, one-off cost, lead time, ownership and expected life.
- Lead time: tooling, first samples and production, for each quantity.
- Samples: cost and timing for first-off samples and for the golden sample.
- Suggested design changes that would cut cost or risk without changing the look (DFM feedback).
- Finishing: lacquer / plating process, colour matching method and the minimum charge per part and per batch.
- Packing and shipping: cartons per pallet and how the glass is protected.

## 9. Premium quality requirements

- Class A cosmetic surfaces on all visible parts: no spinning marks, dents, scratches, inclusions or orange peel, inspected at 50 cm under daylight.
- Gloss and colour match: to be agreed against an approved sample (and between parts of the same colour).
- Minimum wall thickness 1.5 mm on spun parts after forming, for a solid feel (UNVERIFIED).
- Weight plate clamped by the three band screws so nothing rattles; shake test.
- Windows: clean laser-cut edges, deburred, masked so the lacquer line is crisp; even glow through every window.
- Target total lamp mass 1.2 kg ± 10%.
- Masked two-tone line level all round; lantern glass sits square with no rattle; cap twists on smoothly to a positive stop.
- Golden sample approval before production; production inspected against the approved golden sample (AQL to be agreed).

## 10. Unverified values and safety items

- UNVERIFIED: F-01 Base: wall thickness limits for metal spinning come from unverified rule data
- UNVERIFIED: F-05 Nameplate: wall thickness limits for photo-etched brass sheet (formed after etching) come from unverified rule data
- UNVERIFIED: F-06 Cream band: wall thickness limits for cnc turning from near-net stock (tube, ring blank or close-fitting bar) come from unverified rule data
- UNVERIFIED: F-07 Tower: wall thickness limits for metal spinning come from unverified rule data
- UNVERIFIED: F-08 Window diffuser: wall thickness limits for cut and finished glass tube come from unverified rule data
- UNVERIFIED: F-11 Dimmer knob: wall thickness limits for cnc turning from near-net stock (tube, ring blank or close-fitting bar) come from unverified rule data
- UNVERIFIED: F-12 Gallery: wall thickness limits for metal spinning come from unverified rule data
- UNVERIFIED: F-13 Gallery railing: wall thickness limits for photo-etched brass sheet (formed after etching) come from unverified rule data
- UNVERIFIED: F-14 Lantern frame: wall thickness limits for cnc turning from near-net stock (tube, ring blank or close-fitting bar) come from unverified rule data
- UNVERIFIED: F-15 Lantern glass: wall thickness limits for cut and finished glass tube come from unverified rule data
- UNVERIFIED: F-17 Cap: wall thickness limits for metal spinning come from unverified rule data
- UNVERIFIED: F-18 Cap bayonet spigot: wall thickness limits for cnc turning from near-net stock (tube, ring blank or close-fitting bar) come from unverified rule data
- UNVERIFIED: F-19 Finial: wall thickness limits for cnc turning from near-net stock (tube, ring blank or close-fitting bar) come from unverified rule data

- SAFETY: Base: tip-over stability to be tested on the finished lamp
- SAFETY: Weight plate: tip-over stability to be tested on the finished lamp
- SAFETY: Tower: sharp edges must be removed
- SAFETY: Window diffuser: glass breakage, edge finishing and retention to be verified
- SAFETY: Tower light: certified component; electrical safety to be verified by a test lab
- SAFETY: Tower light: Li-ion battery safety: protection circuit, UN38.3 and IEC 62133-2 to be verified
- SAFETY: Dimmer: certified component; electrical safety to be verified by a test lab
- SAFETY: Dimmer: Li-ion battery safety: protection circuit, UN38.3 and IEC 62133-2 to be verified
- SAFETY: Lantern glass: glass breakage, edge finishing and retention to be verified
- SAFETY: Lantern LED: certified component; electrical safety to be verified by a test lab
- SAFETY: Lantern LED: Li-ion battery safety: protection circuit, UN38.3 and IEC 62133-2 to be verified
- SAFETY: Battery pack: certified component; electrical safety to be verified by a test lab
- SAFETY: Battery pack: Li-ion battery safety: protection circuit, UN38.3 and IEC 62133-2 to be verified
- SAFETY: Control board: certified component; electrical safety to be verified by a test lab
- SAFETY: Control board: Li-ion battery safety: protection circuit, UN38.3 and IEC 62133-2 to be verified

## 11. Attachments

- drawings/: one PDF and one SVG per made-to-drawing part (dimensions for quotation, tolerances to be agreed).
- step/: one STEP file per made-to-drawing part, plus the full assembly.
- bom.csv: full bill of materials (part numbers, materials, processes; electronics marked as a separate RFQ).
- rfq.md / rfq.pdf: this document.
